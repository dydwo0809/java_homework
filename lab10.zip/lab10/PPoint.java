/**
    @author yongjae
*/

package kr.ac.kookmin.cs;

/**
  receive x and y
*/
public class PPoint {
    int xA;
    int yA;
  /**
    construct
  */
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
  /**
    get xA
  */
    public int getX() {
        return xA;
    }
  /**
    get yA
  */
    public int getY() {
        return yA;
    }
}
