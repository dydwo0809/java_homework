import java.io.*;
import java.util.*;

public class Buf {

	public static void main(String[] args) throws IOException{
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
			try {	
				String s = in.readLine();
				if (s.equals("quit")) {
					break;
				}
				StringTokenizer st = new StringTokenizer(s);
				int count = st.countTokens();
				System.out.println("There are " + count + " words in this line.");
				for (int i = 0 ; i < count ; i++) {
					System.out.println(st.nextToken());
				}
			}
			catch(IOException e){
				System.out.println("IOException����!");
			}
		}

	}

}
